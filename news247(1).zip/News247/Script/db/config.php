<?php
//Database Server Name:
DEFINE('DBHost','YOUR SEVER NAME');

//Database Username:
DEFINE('DBUser', 'YOUR USERNAME');

//Database Password:
DEFINE('DBPass','YOUR PASSWORD');

//Database Name:
DEFINE('DBName','YOUR DB NAME');

//Character set:
DEFINE('DBCharset','utf8mb4');

//Database Collation:
DEFINE('DBCollation', 'utf8_general_ci');

//Database Prefix:
DEFINE('DBPrefix', '');
?>
